# CCP

CCP is a python program for getting the most common patterns of different layers in a multilayer network.

## Getting Started

1. In order to download CCP, you should clone this repository via the commands

​       `git clone https://github.com/wangbingbo2019/CCP.git`

​       `cd CCP`

2. Prepare the environment for running the python program and install  the dependencies libraries of CCP which are listed in requirements.txt.

3. Once you have prepared the environment and download the repository, you can run in the command line

​        `python CCP.py input1.xlsx ouput1.xlsx output2.xlsx` 

## -------------------------------------------------

##### Files you need to prepare to run CCP.py

###### input files

input1.xlsx (a multilayer directed network. This excel contains multiple sheets and each sheet stores all edges of  a single layer network of a multilayer network. For each sheet, The first column is source node and the second column is target node of a directed edge. ), the input_example.xlsx is an example of input1.xlsx. You can input nodes of type int or string. 

###### output files

(1) output1.xlsx (a multilayer directed network with new weight), you need to create an empty excel output1.xlsx before running the program. 

(2)output2.xlsx (edges of CCPs for each network of a multilayer network),  you need to create an empty excel output2.xlsx before running the program. 

## Citation

If you use the software or the LD Score regression intercept, please cite

Conserved Control Path in Multilayer Networks by Bingbo Wang, Xiujuan Ma, Cunchi Wang, Mingjie Zhang, Qianhua Gong, Lin Gao





