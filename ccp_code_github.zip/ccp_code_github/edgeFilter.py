#! /usr/bin/env python

'''
Created on 2017,6,25

@author: Qianhua Gong
'''
import os
import sys
import xlrd
import networkx as nx
from decimal import Decimal
from xlutils.copy import copy

def label_one_net(read_sheet, index, fileout=None):
    '''
    get edge labels(critical, ordinary, redundant) for edges in network
    diGraph: path of a digraph 
    fileout: contain all edge labels of the digraph
    index: write the result of edge classification to index sheet of the fileout
    return the proportion of each edge label
    '''
    nodetype='str'
    edge=readFromFile(read_sheet)
    diGraph=gen_Digraph_from_edges(read_sheet)
   
    M=get_M(edge)
   
    (out_set,in_set)=get_endpoints(diGraph.edges())
    
    #save the matched nodes of out_set and in_set respectively
    (matched_out_set,matched_in_set)=get_endpoints(M)
    unmatched_out_set=out_set.difference(matched_out_set)
    unmatched_in_set=in_set.difference(matched_in_set)

    #convert the digraph into a bipartite graph
    inv_diGraph=nx.DiGraph()
    
    #construct the first kind of directed graph
    for edge in diGraph.edges():
        if edge in M:
            inv_diGraph.add_edge('out'+str(edge[0]),'in'+str(edge[1]))
        else:
            inv_diGraph.add_edge('in'+str(edge[1]),'out'+str(edge[0]))
    
    sccs=[] #save all strongly connected components with a node number greater than 1
    for scc in sorted(nx.strongly_connected_component_subgraphs(inv_diGraph),
                                key=len, reverse=True):
        if len(scc)>1:
            sccs.append(scc)
    
    ordinary_edges=set()#The edges on both simple paths are ordinary edges
    for scc in sccs:
        edges=scc.edges()
        for (u,v) in edges:
            ordinary_edges.add(transfer_biEdge(u, v,nodetype=nodetype))
    
    if len(unmatched_in_set)>0:
        #construct the second kind of directed graph
        inv_diGraph.clear()
        for edge in diGraph.edges():
            if edge[0] in matched_out_set:
                if edge in M:
                    inv_diGraph.add_edge('out'+str(edge[0]),'in'+str(edge[1]))
                else:
                    inv_diGraph.add_edge('in'+str(edge[1]),'out'+str(edge[0]))
        for root in unmatched_in_set:
            dsp=get_all_edges_in_dsp(inv_diGraph, 'in'+str(root))
            for edge in dsp:
                ordinary_edges.add(transfer_biEdge(edge[0], edge[1],nodetype=nodetype))
    if len(unmatched_out_set)>0:
        #construct the third kind of directed graph
        inv_diGraph.clear()
        for edge in diGraph.edges():
            if edge[1] in matched_in_set:
                if edge in M:
                    inv_diGraph.add_edge('in'+str(edge[1]),'out'+str(edge[0]))
                else:
                    inv_diGraph.add_edge('out'+str(edge[0]),'in'+str(edge[1])) 
        for root in unmatched_out_set:
            dsp=get_all_edges_in_dsp(inv_diGraph, 'out'+str(root))
            for edge in dsp:
                ordinary_edges.add(transfer_biEdge(edge[0], edge[1],nodetype=nodetype))
    
    #write the edge labels into fileout
    if fileout!=None:
        rb = xlrd.open_workbook(fileout)
        wb = copy(rb)
        write_sheet = wb.get_sheet(index)
        
        row = 0
        for edge in diGraph.edges():
            edge=(edge[0],edge[1])
            write_sheet.write(row, 0, edge[0])
            write_sheet.write(row, 1, edge[1])
            
            if edge in ordinary_edges:
                write_sheet.write(row, 2, 'ordinary')
            else:
                if edge in M:
                    write_sheet.write(row, 2, 'critical')
                else:
                    write_sheet.write(row, 2, 'redundant')
            row += 1      
        os.remove(fileout)
        wb.save(fileout)
        
    critical_edges=set(M).difference(ordinary_edges)
    redundant_edges=set(diGraph.edges())-set(M).union(ordinary_edges)
    totalEdges=len(diGraph.edges())
    num_criticalEdges=len(critical_edges)
    num_redundantEdges=len(redundant_edges)
    
    print ('number of ordinary, critical, redundant edges = ',len(ordinary_edges),num_criticalEdges,num_redundantEdges)
    
    result={}  #store the proportion of each edge label
    result['critical']=Decimal(str(num_criticalEdges*1.0/totalEdges)).quantize(Decimal('0.0000'))
    result['ordinary']=Decimal(str(len(ordinary_edges)*1.0/totalEdges)).quantize(Decimal('0.0000'))
    result['redundant']=Decimal(str(num_redundantEdges*1.0/totalEdges)).quantize(Decimal('0.0000'))
    
    return result
    
def label_all_nets(filein, fileout=None):
    rb = xlrd.open_workbook(filein)
    sheet_name = rb.sheet_names()
    
    for sheet_num in range(0,len(sheet_name)):
        read_sheet = rb.sheets()[sheet_num]
        result = label_one_net(read_sheet, sheet_num, fileout)
        print('-----finish the edge classification of the ' + str(sheet_num+1) + '-th network-----')
        
        
def get_endpoints(edges):
    '''
    return out_set and in_set according to the directed list(edges)
    '''
    out_set=set()
    in_set=set()
    for e in edges:
        out_set.add(e[0])
        in_set.add(e[1])
    return (out_set,in_set)
    
def get_all_edges_in_dsp(diGraph,root):
    '''
    return all edges in simple paths starting from root node in diGraph
    '''
    edgeTo=breadth_first_search(diGraph, root)
    edges=[]
    for key in iter(edgeTo.keys()):
        us=edgeTo[key]
        if us==None:
            continue
        for u in us:
            edges.append((u,key))
    return edges

def breadth_first_search(diGraph,root=None):
    queue = []
    visited={}
    edgeTo={}
    node_neighbors={}
    for edge in diGraph.edges():
        u=edge[0]
        v=edge[1]
        if u not in node_neighbors.keys():
            node_neighbors[u]=[v]
        else:
            node_neighbors[u].append(v)
            
    def bfs():
        while len(queue)> 0:
            node=queue.pop(0)
            visited[node] = True
            if node in node_neighbors.keys():
                for n in node_neighbors[node]:
                    if n not in edgeTo.keys():
                        edgeTo[n]=set([node])
                    else:
                        edgeTo[n].add(node)
                    if n not in visited and n not in queue:
                        queue.append(n)       

    if root:
        queue.append(root)
        edgeTo[root]=None
        bfs()

    return edgeTo
    
def transfer_biEdge(u,v,nodetype='str'):
    '''
    convert the edges identified by out and in into the original edges and return(convert the node type into string if it is int)
    '''                
    if u.startswith('in'):
        if nodetype=='int':
            return (str(v.strip('out')),str(u.strip('in')))
        else: 
            return (v.strip('out'),u.strip('in'))
    else:
        if nodetype=='int':
            return (str(u.strip('out')),str(v.strip('in')))
        else:
            return (u.strip('out'),v.strip('in'))
       
      
def get_M(edge):
    '''
    get a maximum matching of a graph with edge
    ''' 
    nx,ny=[],[]
    mx,my={},{}
    for item in edge.items():
        nx.append(item[0])
        mx[item[0]]=-1
        for inNode in item[1]:
            if inNode not in ny:
                ny.append(inNode)
                my[inNode]=-1
    M=genInitialMaxMatch(edge,nx,ny,mx,my)

    return M
    
def gen_Digraph_from_edges(read_sheet):
    '''
    construct digraph from the list of edges
    '''
    edge=[]
    
    for i in range(0,read_sheet.nrows):
        node1 = read_sheet.cell_value(i,0)
        node2 = read_sheet.cell_value(i,1)
        if(isinstance(node1,float)):
            node1 = str(int(node1))
        if(isinstance(node2,float)):
            node2 = str(int(node2))
        edge.append((node1, node2))

    dg=nx.DiGraph()
    dg.add_edges_from(edge)
    return dg
    
def readFromFile(read_sheet):
    '''
    read_sheet: the sheet file in excel storing edges of digraph
    read edges of digraph from read_sheet and represent the digraph with adjacency list
    return edge: edges of the digraph
    '''
    edge={}
    
    for i in range(0,read_sheet.nrows):
        node1 = read_sheet.cell_value(i,0)
        node2 = read_sheet.cell_value(i,1)
        if(isinstance(node1,float)):
            node1 = str(int(node1))
        if(isinstance(node2,float)):
            node2 = str(int(node2))

        if node1==node2: #remove self-loop
            continue
        if node1 in edge:
            edge[node1].append(node2)
        else:
            edge[node1]=[node2]
    
    return edge   

def genInitialMaxMatch(edge,nx,ny,mx,my):
    '''
    generate initial maximum matching
    '''
    visited={}
    MMS=[]
    for i in nx:
        if mx[i]==-1:
            for key in ny:
                visited[key]=0
            path(edge,ny,mx,my,visited,MMS,i)
    return MMS
    
def path(edge,ny,mx,my,visited,MMS,u):
    '''
    find the augmenting path starting from node u, if it exists, return true, otherwise, return false
    '''
    def hasEdge(edge,u,v):
        '''
        judge if there exists edge (u,v)
        '''
        if u not in edge:
            return False
        if v in edge[u]:
            return True
        return False
    for v in ny:
        if hasEdge(edge,u, v) and (not visited[v]):
            visited[v]=1
            if my[v]==-1:
                mx[u]=v
                my[v]=u
                MMS.append((u,v))
                global linkConnectedToNewMatchedNode
                linkConnectedToNewMatchedNode=(u,v)
                return True
            else:
                if path(edge,ny,mx,my,visited,MMS,my[v]): 
                    MMS.remove((my[v],v))
                    mx[u]=v
                    my[v]=u
                    MMS.append((u,v))
                    return True
    return False 

if __name__ == '__main__':
    input_list = sys.argv
    
    input_excel = input_list[1]
    output_excel = input_list[2]
    
    label_all_nets(input_excel, output_excel)