#! /usr/bin/env python

'''
@author: Xiujuan Ma
'''
import os
import sys
import xlrd
import networkx as nx
import edgeFilter as ef
from xlutils.copy import copy

def edge_classification(input_excel, network_excel):
    '''
    classify all edges of networks in input_excel into critical, ordinary and redundant edges
    input_excel: file storing original networks
    network_excel: file storing networks with new_weight
    '''
    ef.label_all_nets(input_excel, network_excel)
    print('Finish edge classification of all single networks of a multilayer network!')

def get_new_weight(network_excel):
    '''
    calculate new weight for original digraph
    network_file: file storing networks with new_weight
    '''
    rb = xlrd.open_workbook(network_excel)
    sheet_name = rb.sheet_names()

    edge_weight = {}
    
    for sheet_number in range(0,len(sheet_name)):
        read_sheet = rb.sheets()[sheet_number]

        for i in range(0,read_sheet.nrows):
            e = (read_sheet.cell_value(i,0),read_sheet.cell_value(i,1))
            edge_type = read_sheet.cell_value(i,2)
            if(e not in edge_weight):
                edge_weight[e] = 0
            if(edge_type !='redundant'):
                edge_weight[e] += 1

    wb = copy(rb)
    for sheet_number in range(0,len(sheet_name)):
        read_sheet = rb.sheets()[sheet_number]
        write_sheet = wb.get_sheet(sheet_number)
        
        for i in range(0,read_sheet.nrows):
            e = (read_sheet.cell_value(i,0),read_sheet.cell_value(i,1))
            if(read_sheet.cell_value(i,2) == 'ordinary'):
                write_sheet.write(i,3,edge_weight[e])

    os.remove(network_excel)
    wb.save(network_excel)

    print('New weights are calculated!')

def get_ccp(input_excel, network_excel, output_excel):
    '''
    get maximum-cardinality matching with maximum weight for OIN(ordinary induce network) and add critical edges to from CCPs
    input_excel: file storing original networks
    network_excel: file storing networks with new_weight
    output_excel:file storing ccps of networks
    '''
    edge_classification(input_excel, network_excel)
    get_new_weight(network_excel)
                        
    rb = xlrd.open_workbook(network_excel)
    sheet_name = rb.sheet_names()
    
    for sheet_number in range(0,len(sheet_name)):   
        dg = nx.DiGraph()  #digraph in sheet_number layer of a multilayer network
        
        read_sheet = rb.sheets()[sheet_number]
        
        critical_edges = []  #'critical edges in sheet_number layer '
        
        for i in range(0,read_sheet.nrows):
            if(read_sheet.cell_value(i,2) == 'critical'):
                critical_edges.append((read_sheet.cell_value(i,0),read_sheet.cell_value(i,1)))
            elif(read_sheet.cell_value(i,2) == 'ordinary'):
                node1 = read_sheet.cell_value(i,0)
                node2 = read_sheet.cell_value(i,1)
                edge_weight = read_sheet.cell_value(i,3)
                dg.add_edge(node1, node2, weight = edge_weight)
                
        in_nodes=[]
        out_nodes=[]
        for node in dg.nodes():
            if dg.out_degree(node)>0:
                out_nodes.append(node)
            if dg.in_degree(node)>0:
                in_nodes.append(node)

        dg1 = nx.Graph()  #convert digraph dg to undirected graph dg1
        for node in out_nodes:
            for (u,v,d) in dg.out_edges(node,data=True):
                dg1.add_edge(u,v+'a',weight=d['weight'])

        mwm = list(nx.algorithms.matching.max_weight_matching(dg1,maxcardinality=True))
        
        #write mwm of OIN and critical edges to output_excel for corresponding layer of a multilayer network
        write_rb = xlrd.open_workbook(output_excel)
        wb = copy(write_rb)
        write_sheet = wb.get_sheet(sheet_number)
        
        row = 0
        for i in range(0,len(mwm)):
            if('a' in mwm[i][0]):
                node1 = mwm[i][1]
                node2 = mwm[i][0].rstrip('a')
                e_weight = dg1.edges[mwm[i][1],mwm[i][0]]['weight']
            else:
                node1 = mwm[i][0]
                node2 = mwm[i][1].rstrip('a')
                e_weight = dg1.edges[mwm[i][0],mwm[i][1]]['weight']
                
            write_sheet.write(row, 0, node1)
            write_sheet.write(row, 1, node2)
            write_sheet.write(row, 2, 'ordinary')
            row += 1
        
        for j in range(0,len(critical_edges)):
            write_sheet.write(row, 0, critical_edges[j][0])
            write_sheet.write(row, 1, critical_edges[j][1])
            write_sheet.write(row, 2, 'critical')
            row += 1
            
        os.remove(output_excel)
        wb.save(output_excel)

        print('-----edges of CCPs in the ' + str(sheet_number+1) + '-th network are gained-----')

if __name__ == '__main__':
    input_list = sys.argv

    input_excel = input_list[1]
    network_excel = input_list[2]
    output_excel = input_list[3]

    get_ccp(input_excel, network_excel, output_excel)

    print('Finish the detection of CCPs for a multilayer network!')